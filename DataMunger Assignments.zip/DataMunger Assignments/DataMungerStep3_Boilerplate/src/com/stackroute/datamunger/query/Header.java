package com.stackroute.datamunger.query;

public class Header {
	
	String [] Header;

	/*
	 * This class should contain a member variable which is a String array, to hold
	 * the headers.
	 */
	
	public Header(String [] header) {
		super();
		this.Header = header;
		
		
		// TODO Auto-generated constructor stub
	}

	public String[] getHeader() {
		return Header;
	}


	public void setHeader(String[] header) {
		Header = header;
	}


	public String[] getHeaders() {
		return null;
	}

}
